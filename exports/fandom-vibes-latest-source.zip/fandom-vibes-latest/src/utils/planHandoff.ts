import type { StarOfDayData } from '../hooks/useStarOfDay';
import type { GridItemData, ImageTier } from '../types';
import type { CardMetadata } from './cardRenderer';

export const DEFAULT_PLAN_HANDOFF_URL = '/api/plan-handoff';
export const VIBE_ATLAS_CAMPAIGN = 'Vibe Atlas Rednote Launch';
export const VIBE_ATLAS_POST_TYPE = 'Static';

export interface PlanFormValues {
  headline: string;
  caption: string;
  platform: string;
  series: string;
  scheduledDate?: string;
}

export type PlanAssetSelection =
  | { kind: 'individual'; image: GridItemData }
  | { kind: 'grid' };

export interface PlanDraftPayload {
  headline: string;
  caption: string;
  captionSeed?: string;
  ctaSeed?: string;
  platform: string;
  series: string;
  type: typeof VIBE_ATLAS_POST_TYPE;
  scheduledDate?: string;
  status: 'Draft';
  origin: 'Automated';
  campaign: string;
  event: string;
  actor: string;
  actorEn: string;
  actorId: string;
  vibe: string;
  vibeEn: string;
  mediaUrl?: string;
  mediaUploadStatus: 'attached' | 'upload_failed';
  mediaError?: string;
  provenance: {
    sourceUrl: string;
    sourceImageUrl?: string;
    sourceContentUrl?: string;
    itemId: string;
    batchKey?: string;
    cardId: string;
    gridId: string;
    gridPosition?: number;
    actorId: string;
    actorName: string;
    generatedAt: string;
    prompt?: string;
    query?: string;
  };
  requirements: string;
}

export async function renderGridCardPng(
  data: StarOfDayData,
  render: GridRenderer,
): Promise<Blob> {
  const canvas = await render(data, 'full');
  return canvasToPngBlob(canvas);
}

interface BuildPayloadOptions {
  data: StarOfDayData;
  selection: PlanAssetSelection;
  form: PlanFormValues;
  sourceUrl: string;
  generatedAt: string;
  mediaUrl?: string;
  uploadError?: string;
}

export interface HandoffResult {
  ok: boolean;
  id: string;
  mediaUploadStatus: 'attached' | 'upload_failed';
  nextAction: 'Attach media' | 'Write caption' | 'Review packet' | 'Paste to XHS admin';
  mediaUrl?: string;
  mediaError?: string;
}

type Fetch = typeof fetch;
type CardRenderer = (metadata: CardMetadata) => Promise<Blob>;
type GridRenderer = (
  data: StarOfDayData,
  variant: 'full',
) => Promise<HTMLCanvasElement>;
export function isDurablePublicUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return (
      url.protocol === 'https:'
      && !url.username
      && !url.password
      && isPublicHostname(url.hostname)
    );
  } catch {
    return false;
  }
}

export function buildPlanDraftPayload({
  data,
  selection,
  form,
  sourceUrl,
  generatedAt,
  mediaUrl,
  uploadError,
}: BuildPayloadOptions): PlanDraftPayload {
  if (mediaUrl && !isDurablePublicUrl(mediaUrl)) {
    throw new Error('Media upload returned a temporary or invalid URL');
  }

  const gridId = `vibe-atlas-${data.date}-${data.actorId}`;
  const image = selection.kind === 'individual' ? selection.image : undefined;
  const gridPosition = image?.gridPosition ?? 0;
  const cardId = image
    ? `${gridId}-card-${gridPosition}-${stableId(image.id)}`
    : `${gridId}-grid`;
  const captionSeed = data.vibeSubtitle.trim() || undefined;
  const ctaSeed = data.ctaSeed?.trim() || undefined;
  const generationPrompt = data.generationPrompt?.trim() || undefined;
  const generationQuery = data.generationQuery?.trim()
    || data.rankedBatches[0]?.query?.trim()
    || undefined;
  const mediaUploadStatus = mediaUrl ? 'attached' : 'upload_failed';
  const requirements = mediaUrl
    ? 'Media attached: generated Vibe Atlas share card.'
    : `Needs media: share-card upload failed${uploadError ? ` — ${uploadError}` : ''}`;

  return {
    headline: form.headline.trim(),
    caption: form.caption.trim(),
    ...(captionSeed ? { captionSeed } : {}),
    ...(ctaSeed ? { ctaSeed } : {}),
    platform: form.platform,
    series: form.series,
    type: VIBE_ATLAS_POST_TYPE,
    ...(form.scheduledDate ? { scheduledDate: form.scheduledDate } : {}),
    status: 'Draft',
    origin: 'Automated',
    campaign: VIBE_ATLAS_CAMPAIGN,
    event: VIBE_ATLAS_CAMPAIGN,
    actor: data.actorName,
    actorEn: data.actorShortNameEn,
    actorId: data.actorId,
    vibe: data.vibeLabel,
    vibeEn: data.vibeLabelEn,
    ...(mediaUrl ? { mediaUrl } : {}),
    mediaUploadStatus,
    ...(uploadError ? { mediaError: uploadError } : {}),
    provenance: {
      sourceUrl,
      ...(image && isDurablePublicUrl(image.id) ? { sourceImageUrl: image.id } : {}),
      ...(image && isDurablePublicUrl(image.url) ? { sourceContentUrl: image.url } : {}),
      itemId: image?.id ?? gridId,
      ...(image?.batchKey ? { batchKey: image.batchKey } : {}),
      cardId,
      gridId,
      ...(image ? { gridPosition } : {}),
      actorId: data.actorId,
      actorName: data.actorName,
      generatedAt: data.generatedAt || generatedAt,
      ...(generationPrompt ? { prompt: generationPrompt } : {}),
      ...(generationQuery ? { query: generationQuery } : {}),
    },
    requirements,
  };
}

export async function renderSelectedCardPng(
  image: GridItemData,
  data: StarOfDayData,
  tier: ImageTier,
  render: CardRenderer,
): Promise<Blob> {
  return render({
    actorName: data.actorName,
    vibeEmoji: data.vibeEmoji,
    vibeLabel: data.vibeLabel,
    vibeLabelEn: data.vibeLabelEn,
    date: data.date,
    imageUrl: image.thumbnail,
    accentColor: data.actorAccentColor,
    tier,
  });
}

export async function sendPlanHandoff(
  blob: Blob,
  payload: PlanDraftPayload,
  handoffUrl = DEFAULT_PLAN_HANDOFF_URL,
  fetchImpl: Fetch = fetch,
): Promise<HandoffResult> {
  const formData = new FormData();
  formData.append('file', new File([blob], 'vibe-atlas-share-card.png', { type: 'image/png' }));
  formData.append('draft', JSON.stringify(payload));

  const response = await fetchImpl(handoffUrl, {
    method: 'POST',
    body: formData,
  });
  const body = await readJson(response);

  if (!response.ok) {
    throw new Error(stringField(body, 'error') || `PLAN handoff failed (HTTP ${response.status})`);
  }

  const id = stringField(body, 'id');
  const mediaUploadStatus = stringField(body, 'mediaUploadStatus');
  const nextAction = stringField(body, 'nextAction');
  if (
    !id
    || (mediaUploadStatus !== 'attached' && mediaUploadStatus !== 'upload_failed')
    || !isNextAction(nextAction)
  ) {
    throw new Error('PLAN handoff returned an invalid response');
  }
  const mediaUrl = stringField(body, 'mediaUrl') || undefined;
  if (mediaUrl && !isDurablePublicUrl(mediaUrl)) {
    throw new Error('PLAN handoff returned a temporary or invalid media URL');
  }
  return {
    ok: true,
    id,
    mediaUploadStatus,
    nextAction,
    ...(mediaUrl ? { mediaUrl } : {}),
    ...(stringField(body, 'mediaError') ? { mediaError: stringField(body, 'mediaError') } : {}),
  };
}

function isNextAction(value: string): value is HandoffResult['nextAction'] {
  return [
    'Attach media',
    'Write caption',
    'Review packet',
    'Paste to XHS admin',
  ].includes(value);
}

export function canvasToPngBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error('Failed to generate the Vibe Atlas share-card PNG'));
    }, 'image/png');
  });
}

async function readJson(response: Response): Promise<unknown> {
  const text = await response.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`Endpoint returned invalid JSON (HTTP ${response.status})`);
  }
}

function stringField(value: unknown, field: string): string {
  if (!value || typeof value !== 'object') return '';
  const candidate = Reflect.get(value, field);
  return typeof candidate === 'string' ? candidate : '';
}

function stableId(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function isPublicHostname(hostname: string): boolean {
  const normalized = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    normalized === 'localhost'
    || normalized.endsWith('.localhost')
    || normalized.endsWith('.local')
    || (
      normalized.includes(':')
      && (
        normalized === '::1'
        || normalized.startsWith('fc')
        || normalized.startsWith('fd')
        || normalized.startsWith('fe8')
        || normalized.startsWith('fe9')
        || normalized.startsWith('fea')
        || normalized.startsWith('feb')
      )
    )
  ) {
    return false;
  }

  const octets = normalized.split('.').map(Number);
  if (octets.length !== 4 || octets.some(octet => !Number.isInteger(octet))) return true;
  const [first, second] = octets;
  return !(
    first === 0
    || first === 10
    || first === 127
    || (first === 169 && second === 254)
    || (first === 172 && second >= 16 && second <= 31)
    || (first === 192 && second === 168)
  );
}
