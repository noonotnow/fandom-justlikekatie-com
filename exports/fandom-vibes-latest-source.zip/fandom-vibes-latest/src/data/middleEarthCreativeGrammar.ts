export const memeFlavors = [
  {
    name: 'One Does Not Simply',
    coreEmotion: 'Solemn overwhelm',
    socialSituation: 'An apparently small task reveals impossible levels of lore, bureaucracy, or effort.',
    description: 'Grave overstatement for a very ordinary obstacle.',
    creativeBrief: 'Treat a tiny task like an administrative saga. Keep the joke original; never reproduce a template or quotation.',
    prototype: {
      corePattern: 'A mundane task is announced with wildly disproportionate gravity.',
      defaultStillFamily: 'boromir-council',
      exemplar: { line1: 'ONE EMAIL ON A FRIDAY', line2: 'AN ENTIRE QUEST.' },
      comedicMechanism: 'Solemn overstatement: the scale of the reaction is the punchline.',
      avoid: ['generic hardship', 'earnest perseverance', 'a literal source quotation'],
      mutationRules: ['Name the specific small task from the moment.', 'Escalate its importance absurdly.', 'Land on the mismatch, not advice.'],
    },
  },
  {
    name: 'You Shall Not Pass',
    coreEmotion: 'Firm refusal',
    socialSituation: 'A distraction, bad habit, or unreasonable request reaches a hard boundary.',
    description: 'A dramatic hard stop for distractions and bad ideas.',
    creativeBrief: 'Frame a clear boundary as an original moment of resolve. Do not quote or recreate the original scene.',
    prototype: {
      corePattern: 'An ordinary intrusion meets a comically final boundary.',
      defaultStillFamily: 'gandalf-bridge',
      exemplar: { line1: 'MY WEEKEND: CLOSED.', line2: 'THE EMAIL: STILL TRYING.' },
      comedicMechanism: 'A tiny nuisance is treated as an invader at the gate.',
      avoid: ['motivational resolve', 'generic self-care', 'the source catchphrase'],
      mutationRules: ['Make the intruder concrete.', 'Use a crisp refusal or consequence.', 'Keep the dramatic scale aimed at something mundane.'],
    },
  },
  {
    name: 'Taking the Hobbits to Isengard',
    coreEmotion: 'Chaotic momentum',
    socialSituation: 'Errands, tabs, reminders, or hyperfocus turn into an escalating loop.',
    description: 'Escalating loop energy for spirals, errands, and too many tabs.',
    creativeBrief: 'Build rhythmic, escalating momentum without reproducing the source song, video, or template.',
    prototype: {
      corePattern: 'A harmless first step becomes an uncontrollable loop.',
      defaultStillFamily: 'gollum-smeagol-debate',
      exemplar: { line1: 'ME: ONE QUICK TAB.', line2: 'MY BRAIN: SIDE QUESTS.' },
      comedicMechanism: 'Immediate escalation and repetition-adjacent loss of control.',
      avoid: ['a calm productivity tip', 'explaining the spiral', 'lyrics or repeated source phrases'],
      mutationRules: ['Start with the user’s supposedly small action.', 'Make the second line speed up or multiply it.', 'End before explanation.'],
    },
  },
  {
    name: 'Second Breakfast',
    coreEmotion: 'Cozy indulgence',
    socialSituation: 'A small treat, pause, or reward is entirely justified.',
    description: 'Little-treat logic that escalates immediately.',
    creativeBrief: 'Make the indulgence playful and earned, never moralizing or sentimental.',
    prototype: {
      corePattern: 'A reasonable little reward instantly argues for another.',
      defaultStillFamily: 'hobbits-eating',
      exemplar: { line1: 'ME: ONE LITTLE TREAT.', line2: 'ALSO ME: MAKE IT TWO.' },
      comedicMechanism: 'Cozy self-justification that escalates before anyone can object.',
      avoid: ['wellness affirmation', 'food guilt', 'a long comfort speech'],
      mutationRules: ['Use the specific treat or pause in the moment.', 'Make the escalation immediate.', 'Keep the speaker gently unreasonable.'],
    },
  },
  {
    name: 'Precious / My Precious',
    coreEmotion: 'Delightful obsession',
    socialSituation: 'A favorite object, ritual, fandom detail, or special interest becomes all-consuming.',
    description: 'Lovingly unreasonable attachment to a niche fixation.',
    creativeBrief: 'Express affectionate obsession without character imitation or direct quotation.',
    prototype: {
      corePattern: 'A person denies wanting a thing while obviously already committed.',
      defaultStillFamily: 'gollum-smeagol-debate',
      exemplar: { line1: 'ME: I DO NOT NEED IT.', line2: 'ALSO ME: IT’S ON SALE.' },
      comedicMechanism: 'The denial and the evidence contradict each other instantly.',
      avoid: ['sincere product praise', 'generic retail copy', 'character-voice imitation'],
      mutationRules: ['Name the object, ritual, or niche fixation.', 'Pair denial with incriminating evidence.', 'Let the contradiction be the joke.'],
    },
  },
  {
    name: 'Council of Elrond',
    coreEmotion: 'Collective overthinking',
    socialSituation: 'A group chat, meeting, or decision has far too many opinions.',
    description: 'Committee energy for group chats and decision paralysis.',
    creativeBrief: 'Turn many competing opinions into a compact original scenario.',
    prototype: {
      corePattern: 'One small question causes an unnecessarily formal group deliberation.',
      defaultStillFamily: 'council-wide-shot',
      exemplar: { line1: 'ME: QUICK QUESTION.', line2: 'THE GROUP CHAT: A COUNCIL.' },
      comedicMechanism: 'A tiny decision inflates into committee theatre.',
      avoid: ['teamwork praise', 'a meeting summary', 'generic leadership advice'],
      mutationRules: ['Start with the smallest possible decision.', 'Show the group escalating it.', 'Favor social specificity over lore explanation.'],
    },
  },
  {
    name: 'Samwise Loyalty',
    coreEmotion: 'Gentle enforcement',
    socialSituation: 'A supportive friend refuses to let someone self-isolate, quit, or suffer quietly.',
    description: 'A loyal friend gently rejects the doomed solo plan.',
    creativeBrief: 'Make support funny through a practical refusal or contradiction, never an encouragement poster.',
    prototype: {
      corePattern: 'One friend tries to suffer alone; the loyal friend refuses the premise.',
      defaultStillFamily: 'sam-carrying-frodo',
      exemplar: { line1: 'ME: I’LL SUFFER QUIETLY.', line2: 'MY SAMWISE FRIEND: INCORRECT.' },
      comedicMechanism: 'Supportive contradiction: the friend agrees it is bad, then joins or intervenes anyway.',
      avoid: ['carries the load', 'generic encouragement', 'inspirational quote language', 'a tender summary'],
      mutationRules: ['Map the moment to someone trying to quit, deny, or suffer alone.', 'Make the friend practical, loyal, and slightly deadpan.', 'Include a refusal, twist, or social contradiction.'],
    },
  },
  {
    name: 'Gollum’s Debate',
    coreEmotion: 'Internal conflict',
    socialSituation: 'Two impulses negotiate over discipline, cravings, procrastination, or a bad idea.',
    description: 'Me-versus-me energy for a very bad internal negotiation.',
    creativeBrief: 'Write an original internal debate without imitating dialogue from the films or books.',
    prototype: {
      corePattern: 'The responsible self makes a case; the gremlin self wins with one inconvenient fact.',
      defaultStillFamily: 'gollum-smeagol-debate',
      exemplar: { line1: 'ME: BE RESPONSIBLE.', line2: 'ALSO ME: BUT IT’S ON SALE.' },
      comedicMechanism: 'The second voice instantly derails the first with a selfish exception.',
      avoid: ['earnest self-improvement', 'a balanced pros-and-cons list', 'character imitation'],
      mutationRules: ['Let both lines use modern internal voices.', 'Make the second line undermine the first.', 'Use the moment’s exact temptation when possible.'],
    },
  },
  {
    name: 'Unexpected Journey',
    coreEmotion: 'Reluctant adventure',
    socialSituation: 'An errand, trip, or new project unexpectedly becomes a side quest.',
    description: 'How-did-I-get-here energy for an ordinary plan gone long.',
    creativeBrief: 'Make ordinary escalation feel surprising and original, not earnestly adventurous.',
    prototype: {
      corePattern: 'A simple plan grows into a needless multi-stage mission.',
      defaultStillFamily: 'frodo-quest-burden',
      exemplar: { line1: 'ME: QUICK ERRAND.', line2: 'THREE HOURS: SIDE QUEST.' },
      comedicMechanism: 'The gap between the plan and the outcome is absurdly large.',
      avoid: ['travel inspiration', 'heroic self-discovery', 'a scenic summary'],
      mutationRules: ['Name the first small plan.', 'Reveal the unexpected detour.', 'Keep the speaker baffled, not enlightened.'],
    },
  },
  {
    name: 'Mordor Commute',
    coreEmotion: 'Epic daily dread',
    socialSituation: 'Work, school, traffic, or Monday feels like an unnecessary expedition.',
    description: 'Ordinary dread reframed as an epic inconvenience.',
    creativeBrief: 'Use heightened stakes and dry resilience, never motivational endurance language.',
    prototype: {
      corePattern: 'A routine obligation arrives as if it were an avoidable disaster.',
      defaultStillFamily: 'frodo-quest-burden',
      exemplar: { line1: 'THE FRIDAY SHIFT APPEARED.', line2: 'MY SOUL LEFT THE FELLOWSHIP.' },
      comedicMechanism: 'Epic dread applied to a mundane calendar event.',
      avoid: ['workplace encouragement', 'grit rhetoric', 'a literal journey description'],
      mutationRules: ['Use the user’s specific obligation.', 'Make the reaction disproportionate and dry.', 'Let exhaustion be funny, not noble.'],
    },
  },
  {
    name: 'The Beacons Are Lit',
    coreEmotion: 'Urgent rallying',
    socialSituation: 'A group needs backup, the situation escalated, or help is required now.',
    description: 'Call-for-backup energy for a suddenly too-big problem.',
    creativeBrief: 'Create a compact original escalation, not a heroic call to action.',
    prototype: {
      corePattern: 'A small problem is announced like it requires immediate reinforcements.',
      defaultStillFamily: 'council-wide-shot',
      exemplar: { line1: 'ME: SMALL PROBLEM.', line2: 'GROUP CHAT: SEND BACKUP.' },
      comedicMechanism: 'A minor issue triggers an absurdly official emergency response.',
      avoid: ['inspirational rallying', 'actual emergency instructions', 'a long battle speech'],
      mutationRules: ['Start with the user’s modest problem.', 'Escalate to collective backup.', 'Keep the urgency socially exaggerated.'],
    },
  },
  {
    name: 'Fly, You Fools',
    coreEmotion: 'Immediate escape',
    socialSituation: 'It is time to leave a bad decision, toxic thread, or doomed situation.',
    description: 'Log-off-now instinct for a bad idea that has gone too far.',
    creativeBrief: 'Use a decisive exit impulse without quoting or recreating the original scene.',
    prototype: {
      corePattern: 'One more tiny engagement is clearly the wrong choice; common sense calls for escape.',
      defaultStillFamily: 'gandalf-bridge',
      exemplar: { line1: 'ME: ONE MORE REPLY.', line2: 'MY COMMON SENSE: LOG OFF.' },
      comedicMechanism: 'The urge to keep going meets an immediate, blunt evacuation order.',
      avoid: ['a self-help boundary', 'a literal source quote', 'a long warning'],
      mutationRules: ['Name the temptation to stay.', 'Make the exit command short and final.', 'Use urgency as the punchline.'],
    },
  },
  {
    name: 'I Am No Man',
    coreEmotion: 'Underdog reversal',
    socialSituation: 'Someone underestimated reveals competence, confidence, or a decisive win.',
    description: 'Exhausted competence for the person who has to solve it.',
    creativeBrief: 'Celebrate an original reversal without using the source line as on-card copy.',
    prototype: {
      corePattern: 'A task asks who can do it; the underestimated person realizes it is, unfortunately, them.',
      defaultStillFamily: 'eowyn-triumph',
      exemplar: { line1: 'THE TASK: WHO CAN DO THIS?', line2: 'ME, UNFORTUNATELY: ME.' },
      comedicMechanism: 'The triumph is undercut by reluctant self-recognition.',
      avoid: ['generic empowerment', 'victory-poster language', 'the source catchphrase'],
      mutationRules: ['Name the underestimated task or person.', 'Reveal competence with a weary twist.', 'Keep the win slightly inconvenient.'],
    },
  },
] as const;

export type MemeFlavorName = (typeof memeFlavors)[number]['name'];

/**
 * A Meme Flavor supplies the Middle-earth social world; a Comic Mechanism
 * supplies the actual setup-to-punchline turn. These are original comedy
 * patterns, not source captions or recreatable meme templates.
 */
export const comicMechanisms = [
  {
    name: 'Severity inversion',
    description: 'Treat a small modern inconvenience with wildly disproportionate Middle-earth gravity.',
    selectionCues: ['mundane dread', 'Friday work', 'minor task', 'commute'],
    avoid: ['generic hardship', 'earnest endurance', 'motivational suffering'],
    exemplarShape: 'A tiny obligation appears / the reaction declares an impossible quest.',
  },
  {
    name: 'Intent reversal',
    description: 'The speaker’s stated plan is immediately undone by what they actually want or do.',
    selectionCues: ['bad plan', 'temptation', 'willpower', 'one more thing'],
    avoid: ['a balanced pros-and-cons list', 'self-improvement advice'],
    exemplarShape: 'ME: sensible intention / ALSO ME: the immediate exception.',
  },
  {
    name: 'Escalating repetition',
    description: 'One harmless step multiplies into a faster, more ridiculous loop.',
    selectionCues: ['tabs', 'errands', 'spiral', 'again', 'too many'],
    avoid: ['a productivity tip', 'explaining every step of the spiral'],
    exemplarShape: 'One quick action / suddenly, a multiplying side quest.',
  },
  {
    name: 'Ceremonial setup / petty punchline',
    description: 'A grand formal declaration lands on a tiny, specific modern problem.',
    selectionCues: ['meeting', 'group chat', 'announcement', 'small decision'],
    avoid: ['heroic rallying', 'actual emergency language'],
    exemplarShape: 'A solemn proclamation / a petty practical consequence.',
  },
  {
    name: 'Literal misread / wordplay',
    description: 'A phrase or rule is taken too literally, revealing an inconveniently silly meaning.',
    selectionCues: ['ambiguous wording', 'instructions', 'signs', 'rules'],
    avoid: ['forced puns', 'explaining the wordplay'],
    exemplarShape: 'A literal reading / the absurd real-world implication.',
  },
  {
    name: 'Relationship-specific contradiction',
    description: 'A familiar relationship makes one person’s stated plan impossible or immediately challenged.',
    selectionCues: ['friends', 'Sam and Frodo', 'group dynamic', 'support'],
    avoid: ['tender tribute', 'generic friendship praise', 'inspirational support'],
    exemplarShape: 'One friend insists on a doomed plan / the other calmly refuses the premise.',
  },
  {
    name: 'Delighted fandom-lawyer correction',
    description: 'A lore-minded voice eagerly corrects the premise, then makes the correction funnier than the question.',
    selectionCues: ['Why did they not take the Eagles?', 'lore question', 'canon detail'],
    avoid: ['a lecture', 'gatekeeping', 'long factual explanation'],
    exemplarShape: 'A confident fandom question / an overprepared correction with a petty payoff.',
  },
] as const;

export type ComicMechanismName = (typeof comicMechanisms)[number]['name'];

export const defaultComicMechanismsByFlavor = {
  'One Does Not Simply': ['Severity inversion', 'Ceremonial setup / petty punchline'],
  'You Shall Not Pass': ['Ceremonial setup / petty punchline', 'Severity inversion'],
  'Taking the Hobbits to Isengard': ['Escalating repetition'],
  'Second Breakfast': ['Intent reversal', 'Escalating repetition'],
  'Precious / My Precious': ['Intent reversal', 'Relationship-specific contradiction'],
  'Council of Elrond': ['Ceremonial setup / petty punchline', 'Escalating repetition'],
  'Samwise Loyalty': ['Relationship-specific contradiction', 'Severity inversion'],
  'Gollum’s Debate': ['Intent reversal', 'Relationship-specific contradiction'],
  'Unexpected Journey': ['Severity inversion', 'Escalating repetition'],
  'Mordor Commute': ['Severity inversion', 'Ceremonial setup / petty punchline'],
  'The Beacons Are Lit': ['Ceremonial setup / petty punchline', 'Escalating repetition'],
  'Fly, You Fools': ['Intent reversal', 'Ceremonial setup / petty punchline'],
  'I Am No Man': ['Intent reversal', 'Severity inversion'],
} as const satisfies Record<MemeFlavorName, readonly ComicMechanismName[]>;

export const forbiddenSourceTemplatesByFlavor = {
  'One Does Not Simply': ['one does not simply'],
  'You Shall Not Pass': ['you shall not pass'],
  'Taking the Hobbits to Isengard': ['taking the hobbits to isengard'],
  'Second Breakfast': ['what about second breakfast'],
  'Precious / My Precious': ['my precious'],
  'Council of Elrond': ['you have my sword'],
  'Samwise Loyalty': ["i can't carry it for you, but i can carry you"],
  'Gollum’s Debate': ['we wants it'],
  'Unexpected Journey': ["i'm going on an adventure"],
  'Mordor Commute': ['one does not simply walk into mordor'],
  'The Beacons Are Lit': ['the beacons are lit'],
  'Fly, You Fools': ['fly, you fools'],
  'I Am No Man': ['i am no man'],
} as const satisfies Record<MemeFlavorName, readonly string[]>;

export const aesthetics = [
  { name: 'Epic parchment', description: 'Weathered, cinematic, and quest-ready.' },
  { name: 'Medieval marginalia', description: 'Bookish notes, tiny details, illuminated edges.' },
  { name: 'VHS fantasy still', description: 'Soft grain, nostalgic drama, late-night lore.' },
  { name: 'Cozy Hobbiton', description: 'Warm lamplight, food, rest, and gentle humor.' },
  { name: 'Dark Mordor productivity', description: 'High contrast, deadlines, and heroic endurance.' },
  { name: 'Illuminated manuscript', description: 'Decorative, ceremonial, and richly composed.' },
  { name: 'Chaotic group chat', description: 'Fast, messy, socially overcommitted energy.' },
  { name: 'Study-card mode', description: 'Clear, clever, useful, and easy to save.' },
] as const;

export type AestheticName = (typeof aesthetics)[number]['name'];

export const artifactTypes = [
  'Meme card',
  'Vocabulary card',
  'Hero card',
  'Shareable one-pager',
  'Carousel slide',
  'Reaction image',
] as const;

export type ArtifactType = (typeof artifactTypes)[number];