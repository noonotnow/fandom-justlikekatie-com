Publish packet notes

Cover image is not in the registered attachment manifest; download it directly: https://images.xhs.justlikekatie.com/images/sha256/70/6c/706ce940ddf5c034202cae8c70890cd2ed3c2fdc7e2bc952be67cf1f471b560a.png
Media 1 is a video and is not bundled; it is delivered as stored at: https://images.xhs.justlikekatie.com/videos/assets/77/778de118-1c55-4a4d-b8a7-2e17cc66f900.mp4
